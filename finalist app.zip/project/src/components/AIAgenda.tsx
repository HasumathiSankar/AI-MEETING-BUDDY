import React, { useState } from 'react';
import { FileText, Brain, CheckCircle, Clock, Users, Target } from 'lucide-react';

const AIAgenda: React.FC = () => {
  const [showQuestions, setShowQuestions] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [generatedAgenda, setGeneratedAgenda] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const questions = [
    {
      id: 'meetingPurpose',
      question: "What's the main purpose of today's meeting?",
      type: 'select',
      options: [
        'Quarterly Business Review',
        'New Product Launch Discussion',
        'Partnership Strategy Planning',
        'Performance Review & Feedback',
        'Market Expansion Planning',
        'Contract Negotiation',
        'Training & Development Session',
        'Crisis Management Discussion'
      ]
    },
    {
      id: 'keyParticipants',
      question: 'Who are the key participants and their roles?',
      type: 'textarea',
      placeholder: 'e.g., John Smith (Regional Manager), Sarah Johnson (Product Lead), etc.'
    },
    {
      id: 'urgentTopics',
      question: 'Are there any urgent topics that must be discussed?',
      type: 'textarea',
      placeholder: 'List any critical issues, deadlines, or urgent decisions needed...'
    },
    {
      id: 'expectedOutcome',
      question: 'What outcome do you expect from this meeting?',
      type: 'select',
      options: [
        'Make key decisions',
        'Align on strategy',
        'Review progress & metrics',
        'Plan next quarter activities',
        'Resolve conflicts or issues',
        'Share updates & information',
        'Negotiate terms',
        'Training completion'
      ]
    },
    {
      id: 'timeConstraints',
      question: 'How much time do you have for this meeting?',
      type: 'select',
      options: ['30 minutes', '45 minutes', '1 hour', '1.5 hours', '2 hours', '2+ hours']
    },
    {
      id: 'additionalInfo',
      question: 'Any additional context or special requirements?',
      type: 'textarea',
      placeholder: 'Cultural considerations, specific tools needed, presentation requirements, etc.'
    }
  ];

  const pastMeetingTopics = [
    'Q3 performance metrics review',
    'New market penetration strategies',
    'Supply chain optimization',
    'Digital transformation initiatives',
    'Customer satisfaction improvements',
    'Partnership expansion opportunities',
    'Cost reduction strategies',
    'Training program effectiveness'
  ];

  const handleStartGeneration = () => {
    setShowQuestions(true);
    setCurrentQuestionIndex(0);
  };

  const handleAnswerChange = (value: string) => {
    setAnswers(prev => ({
      ...prev,
      [questions[currentQuestionIndex].id]: value
    }));
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      generateAgenda();
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const generateAgenda = () => {
    setIsGenerating(true);
    
    // Simulate AI processing
    setTimeout(() => {
      const agenda = {
        title: `${answers.meetingPurpose} - ${new Date().toLocaleDateString()}`,
        duration: answers.timeConstraints,
        objective: answers.expectedOutcome,
        participants: answers.keyParticipants?.split(',').map(p => p.trim()).filter(p => p) || ['Team Members'],
        agenda: generateAgendaItems(),
        preparationNotes: generatePreparationNotes(),
        followUpActions: generateFollowUpActions()
      };
      
      setGeneratedAgenda(agenda);
      setIsGenerating(false);
      setShowQuestions(false);
    }, 2000);
  };

  const generateAgendaItems = () => {
    const baseItems = [
      { time: '5 min', item: 'Welcome & Introductions', type: 'opening' },
      { time: '10 min', item: 'Review of Previous Meeting Action Items', type: 'review' }
    ];

    const purposeSpecificItems: Record<string, any[]> = {
      'Quarterly Business Review': [
        { time: '15 min', item: 'Q3 Performance Metrics Analysis', type: 'discussion' },
        { time: '20 min', item: 'Market Trends & Competitive Landscape', type: 'presentation' },
        { time: '15 min', item: 'Q4 Goals & Strategic Initiatives', type: 'planning' }
      ],
      'New Product Launch Discussion': [
        { time: '15 min', item: 'Product Features & Market Positioning', type: 'presentation' },
        { time: '20 min', item: 'Launch Timeline & Marketing Strategy', type: 'planning' },
        { time: '10 min', item: 'Resource Allocation & Budget Review', type: 'discussion' }
      ],
      'Partnership Strategy Planning': [
        { time: '15 min', item: 'Current Partnership Performance Review', type: 'review' },
        { time: '20 min', item: 'New Partnership Opportunities', type: 'discussion' },
        { time: '15 min', item: 'Strategic Alignment & Next Steps', type: 'planning' }
      ]
    };

    const specificItems = purposeSpecificItems[answers.meetingPurpose] || [
      { time: '20 min', item: 'Main Discussion Topic', type: 'discussion' },
      { time: '15 min', item: 'Strategic Planning', type: 'planning' }
    ];

    if (answers.urgentTopics) {
      specificItems.unshift({
        time: '10 min',
        item: `Urgent: ${answers.urgentTopics.substring(0, 50)}...`,
        type: 'urgent'
      });
    }

    const closingItems = [
      { time: '10 min', item: 'Key Decisions & Action Items Summary', type: 'summary' },
      { time: '5 min', item: 'Next Meeting & Follow-up Schedule', type: 'closing' }
    ];

    return [...baseItems, ...specificItems, ...closingItems];
  };

  const generatePreparationNotes = () => {
    const notes = [
      '📊 Review previous quarter performance data',
      '📈 Prepare market analysis reports',
      '💼 Bring partnership agreements for reference',
      '📋 Update project status reports'
    ];

    if (answers.urgentTopics) {
      notes.unshift(`🚨 Priority: ${answers.urgentTopics.substring(0, 100)}`);
    }

    return notes;
  };

  const generateFollowUpActions = () => {
    return [
      { action: 'Send meeting summary to all participants', owner: 'Meeting Organizer', deadline: '24 hours' },
      { action: 'Update project tracking systems', owner: 'Team Leads', deadline: '2 days' },
      { action: 'Schedule follow-up meetings as needed', owner: 'Meeting Organizer', deadline: '1 week' },
      { action: `Follow up on ${answers.expectedOutcome?.toLowerCase()}`, owner: 'All Participants', deadline: '1 week' }
    ];
  };

  const resetForm = () => {
    setShowQuestions(false);
    setCurrentQuestionIndex(0);
    setAnswers({});
    setGeneratedAgenda(null);
  };

  if (isGenerating) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Brain className="h-16 w-16 text-blue-600 mx-auto mb-4 animate-pulse" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">AI is generating your agenda...</h2>
          <p className="text-gray-600">Analyzing your responses and past meeting data</p>
          <div className="mt-4">
            <div className="w-64 bg-gray-200 rounded-full h-2 mx-auto">
              <div className="bg-blue-600 h-2 rounded-full animate-pulse" style={{ width: '70%' }}></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (generatedAgenda) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Generated Meeting Agenda</h1>
            <p className="mt-2 text-gray-600">AI-powered agenda based on your requirements</p>
          </div>
          <button
            onClick={resetForm}
            className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition-colors"
          >
            Create New Agenda
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="border-b border-gray-200 pb-4 mb-6">
            <h2 className="text-xl font-bold text-gray-900">{generatedAgenda.title}</h2>
            <div className="flex items-center space-x-6 mt-2 text-sm text-gray-600">
              <span className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                Duration: {generatedAgenda.duration}
              </span>
              <span className="flex items-center">
                <Users className="h-4 w-4 mr-1" />
                {generatedAgenda.participants.length} Participants
              </span>
              <span className="flex items-center">
                <Target className="h-4 w-4 mr-1" />
                Objective: {generatedAgenda.objective}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Agenda */}
            <div className="lg:col-span-2">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Meeting Agenda</h3>
              <div className="space-y-3">
                {generatedAgenda.agenda.map((item: any, index: number) => (
                  <div key={index} className={`flex items-center p-3 rounded-lg border-l-4 ${
                    item.type === 'urgent' ? 'border-red-500 bg-red-50' :
                    item.type === 'opening' ? 'border-green-500 bg-green-50' :
                    item.type === 'closing' ? 'border-blue-500 bg-blue-50' :
                    'border-gray-300 bg-gray-50'
                  }`}>
                    <div className="flex-shrink-0 w-16 text-sm font-medium text-gray-600">
                      {item.time}
                    </div>
                    <div className="flex-1">
                      <span className="text-gray-900">{item.item}</span>
                      <span className={`ml-2 text-xs px-2 py-1 rounded-full ${
                        item.type === 'urgent' ? 'bg-red-100 text-red-800' :
                        item.type === 'discussion' ? 'bg-blue-100 text-blue-800' :
                        item.type === 'presentation' ? 'bg-purple-100 text-purple-800' :
                        item.type === 'planning' ? 'bg-green-100 text-green-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {item.type}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Preparation Notes */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Preparation Notes</h3>
                <div className="space-y-2">
                  {generatedAgenda.preparationNotes.map((note: string, index: number) => (
                    <div key={index} className="flex items-start p-2 text-sm text-gray-700 bg-yellow-50 rounded">
                      <span>{note}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Participants */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Participants</h3>
                <div className="space-y-2">
                  {generatedAgenda.participants.map((participant: string, index: number) => (
                    <div key={index} className="flex items-center p-2 text-sm text-gray-700 bg-gray-50 rounded">
                      <Users className="h-4 w-4 mr-2 text-gray-400" />
                      {participant}
                    </div>
                  ))}
                </div>
              </div>

              {/* Follow-up Actions */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Follow-up Actions</h3>
                <div className="space-y-2">
                  {generatedAgenda.followUpActions.map((action: any, index: number) => (
                    <div key={index} className="p-3 text-sm bg-blue-50 rounded-lg border border-blue-200">
                      <div className="font-medium text-gray-900 mb-1">{action.action}</div>
                      <div className="text-xs text-gray-600">
                        Owner: {action.owner} • Due: {action.deadline}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200 flex space-x-4">
            <button className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors">
              Export to PDF
            </button>
            <button className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition-colors">
              Send to Participants
            </button>
            <button className="bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700 transition-colors">
              Save as Template
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (showQuestions) {
    const currentQuestion = questions[currentQuestionIndex];
    
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">AI Agenda Generation</h1>
          <p className="mt-2 text-gray-600">Question {currentQuestionIndex + 1} of {questions.length}</p>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
              style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">{currentQuestion.question}</h2>
          
          {currentQuestion.type === 'select' ? (
            <div className="space-y-3">
              {currentQuestion.options?.map((option) => (
                <label key={option} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name={currentQuestion.id}
                    value={option}
                    checked={answers[currentQuestion.id] === option}
                    onChange={(e) => handleAnswerChange(e.target.value)}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                  />
                  <span className="text-gray-900">{option}</span>
                </label>
              ))}
            </div>
          ) : (
            <textarea
              value={answers[currentQuestion.id] || ''}
              onChange={(e) => handleAnswerChange(e.target.value)}
              placeholder={currentQuestion.placeholder}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          )}

          <div className="flex justify-between items-center mt-8">
            <button
              onClick={handlePreviousQuestion}
              disabled={currentQuestionIndex === 0}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            
            <button
              onClick={handleNextQuestion}
              disabled={!answers[currentQuestion.id]}
              className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {currentQuestionIndex === questions.length - 1 ? 'Generate Agenda' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">AI Agenda Generation</h1>
        <p className="mt-2 text-gray-600">Create intelligent meeting agendas based on your specific needs and past meeting insights.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Main Action Card */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg p-8 border border-blue-200">
          <div className="text-center">
            <Brain className="h-16 w-16 text-blue-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Generate Smart Agenda</h2>
            <p className="text-gray-600 mb-6">
              Answer a few questions about your upcoming meeting, and our AI will create a comprehensive agenda tailored to your needs.
            </p>
            <button
              onClick={handleStartGeneration}
              className="bg-blue-600 text-white px-8 py-3 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors text-lg font-semibold"
            >
              Start AI Generation
            </button>
          </div>
        </div>

        {/* Past Meeting Insights */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <FileText className="h-5 w-5 mr-2" />
            Recent Meeting Topics
          </h2>
          <p className="text-sm text-gray-600 mb-4">
            Our AI learns from your past meetings to suggest relevant agenda items:
          </p>
          <div className="space-y-2">
            {pastMeetingTopics.map((topic, index) => (
              <div key={index} className="flex items-center p-2 text-sm text-gray-700 bg-gray-50 rounded hover:bg-gray-100 transition-colors">
                <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                {topic}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
          <Target className="h-8 w-8 text-blue-600 mx-auto mb-3" />
          <h3 className="font-semibold text-gray-900 mb-2">Purpose-Driven</h3>
          <p className="text-sm text-gray-600">Agendas tailored to your specific meeting objectives and expected outcomes.</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
          <Clock className="h-8 w-8 text-green-600 mx-auto mb-3" />
          <h3 className="font-semibold text-gray-900 mb-2">Time-Optimized</h3>
          <p className="text-sm text-gray-600">Smart time allocation based on your meeting duration and priority topics.</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
          <Users className="h-8 w-8 text-purple-600 mx-auto mb-3" />
          <h3 className="font-semibold text-gray-900 mb-2">Context-Aware</h3>
          <p className="text-sm text-gray-600">Incorporates participant roles and past meeting insights for relevance.</p>
        </div>
      </div>
    </div>
  );
};

export default AIAgenda;