import React, { useState } from 'react';
import { Calendar, Clock, Globe, Users, CheckCircle } from 'lucide-react';

const SmartScheduling: React.FC = () => {
  const [selectedCountries, setSelectedCountries] = useState<string[]>(['India']);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const countries = [
    { id: 'India', name: 'India', timezone: 'Asia/Kolkata', offset: '+05:30' },
    { id: 'Singapore', name: 'Singapore', timezone: 'Asia/Singapore', offset: '+08:00' },
    { id: 'UK', name: 'United Kingdom', timezone: 'Europe/London', offset: '+00:00' },
    { id: 'USA_East', name: 'USA (East Coast)', timezone: 'America/New_York', offset: '-05:00' },
    { id: 'USA_West', name: 'USA (West Coast)', timezone: 'America/Los_Angeles', offset: '-08:00' },
    { id: 'Australia', name: 'Australia (Sydney)', timezone: 'Australia/Sydney', offset: '+11:00' },
    { id: 'Germany', name: 'Germany', timezone: 'Europe/Berlin', offset: '+01:00' },
    { id: 'Japan', name: 'Japan', timezone: 'Asia/Tokyo', offset: '+09:00' },
  ];

  const mockAvailability = {
    India: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
    Singapore: ['10:00', '11:00', '14:00', '15:00', '16:00', '17:00'],
    UK: ['09:00', '10:00', '13:00', '14:00', '15:00', '16:00'],
    USA_East: ['09:00', '10:00', '11:00', '15:00', '16:00', '17:00'],
    USA_West: ['10:00', '11:00', '14:00', '15:00', '16:00', '17:00'],
    Australia: ['09:00', '10:00', '11:00', '13:00', '14:00', '15:00'],
    Germany: ['09:00', '10:00', '14:00', '15:00', '16:00', '17:00'],
    Japan: ['10:00', '11:00', '14:00', '15:00', '16:00', '17:00'],
  };

  const toggleCountry = (countryId: string) => {
    if (countryId === 'India') return; // India is always selected
    
    setSelectedCountries(prev => 
      prev.includes(countryId) 
        ? prev.filter(id => id !== countryId)
        : [...prev, countryId]
    );
  };

  const generateSuggestions = () => {
    setShowSuggestions(true);
  };

  const convertTime = (time: string, fromTimezone: string, toTimezone: string) => {
    const today = new Date();
    const [hours, minutes] = time.split(':');
    const date = new Date(today.getFullYear(), today.getMonth(), today.getDate(), parseInt(hours), parseInt(minutes));
    
    // This is a simplified conversion - in production, you'd use a proper timezone library
    const timezoneOffsets: Record<string, number> = {
      'Asia/Kolkata': 5.5,
      'Asia/Singapore': 8,
      'Europe/London': 0,
      'America/New_York': -5,
      'America/Los_Angeles': -8,
      'Australia/Sydney': 11,
      'Europe/Berlin': 1,
      'Asia/Tokyo': 9,
    };

    const fromOffset = timezoneOffsets[fromTimezone];
    const toOffset = timezoneOffsets[toTimezone];
    const diffHours = toOffset - fromOffset;
    
    const convertedDate = new Date(date.getTime() + (diffHours * 60 * 60 * 1000));
    return convertedDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  const findCommonSlots = () => {
    if (selectedCountries.length < 2) return [];

    const indiaSlots = mockAvailability['India' as keyof typeof mockAvailability];
    const commonSlots = [];

    for (const indiaTime of indiaSlots) {
      const slotData = {
        indiaTime,
        isCommon: true,
        times: [] as Array<{ country: string, time: string, timezone: string }>
      };

      for (const countryId of selectedCountries) {
        const country = countries.find(c => c.id === countryId);
        if (!country) continue;

        const convertedTime = countryId === 'India' 
          ? indiaTime 
          : convertTime(indiaTime, 'Asia/Kolkata', country.timezone);
        
        const availability = mockAvailability[countryId as keyof typeof mockAvailability];
        const isAvailable = availability.includes(convertedTime) || countryId === 'India';

        slotData.times.push({
          country: country.name,
          time: convertedTime,
          timezone: country.offset
        });

        if (!isAvailable) {
          slotData.isCommon = false;
        }
      }

      if (slotData.isCommon) {
        commonSlots.push(slotData);
      }
    }

    return commonSlots;
  };

  const commonSlots = showSuggestions ? findCommonSlots() : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Smart Scheduling</h1>
        <p className="mt-2 text-gray-600">Find the perfect meeting time across multiple time zones with AI-powered suggestions.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Selection Panel */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Globe className="h-5 w-5 mr-2" />
              Select Countries/Regions
            </h2>
            <div className="space-y-3">
              {countries.map((country) => (
                <label key={country.id} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedCountries.includes(country.id)}
                    onChange={() => toggleCountry(country.id)}
                    disabled={country.id === 'India'}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded disabled:opacity-50"
                  />
                  <span className={`flex-1 ${country.id === 'India' ? 'font-medium text-blue-600' : 'text-gray-900'}`}>
                    {country.name}
                  </span>
                  <span className="text-sm text-gray-500">{country.offset}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Select Date
            </h2>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            
            <button
              onClick={generateSuggestions}
              disabled={selectedCountries.length < 2}
              className="w-full mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Generate Smart Suggestions
            </button>
          </div>
        </div>

        {/* Results Panel */}
        <div className="space-y-6">
          {/* Current Time Display */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Clock className="h-5 w-5 mr-2" />
              Current Times
            </h2>
            <div className="space-y-2">
              {selectedCountries.map(countryId => {
                const country = countries.find(c => c.id === countryId);
                if (!country) return null;
                
                const currentTime = new Date().toLocaleTimeString('en-US', {
                  timeZone: country.timezone,
                  hour: '2-digit',
                  minute: '2-digit',
                  hour12: false
                });
                
                return (
                  <div key={countryId} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
                    <span className="text-sm font-medium text-gray-900">{country.name}</span>
                    <span className="text-sm font-mono text-gray-600">{currentTime}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Meeting Suggestions */}
          {showSuggestions && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                Suggested Meeting Times
              </h2>
              
              {commonSlots.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Users className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p>No common available slots found for the selected regions.</p>
                  <p className="text-sm mt-2">Try selecting different regions or a different date.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {commonSlots.slice(0, 4).map((slot, index) => (
                    <div key={index} className="border border-green-200 rounded-lg p-4 bg-green-50 hover:bg-green-100 transition-colors cursor-pointer">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold text-gray-900">Option {index + 1}</h3>
                        <span className="text-xs bg-green-600 text-white px-2 py-1 rounded-full">Available</span>
                      </div>
                      <div className="grid grid-cols-1 gap-2">
                        {slot.times.map((timeSlot, timeIndex) => (
                          <div key={timeIndex} className="flex justify-between items-center text-sm">
                            <span className="text-gray-700">{timeSlot.country}:</span>
                            <span className="font-mono font-medium">{timeSlot.time} ({timeSlot.timezone})</span>
                          </div>
                        ))}
                      </div>
                      <button className="w-full mt-3 bg-green-600 text-white text-sm py-2 rounded-md hover:bg-green-700 transition-colors">
                        Schedule This Meeting
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SmartScheduling;