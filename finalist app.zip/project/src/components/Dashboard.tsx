import React from 'react';
import { Calendar, FileText, Bell, Users, Clock, TrendingUp } from 'lucide-react';

interface DashboardProps {
  setCurrentPage: (page: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ setCurrentPage }) => {
  const stats = [
    {
      name: 'Upcoming Meetings',
      value: '8',
      change: '+2 this week',
      changeType: 'positive',
      icon: Calendar,
    },
    {
      name: 'Pending Follow-ups',
      value: '12',
      change: '-3 completed',
      changeType: 'positive',
      icon: Bell,
    },
    {
      name: 'Total Partners',
      value: '24',
      change: '+4 new regions',
      changeType: 'positive',
      icon: Users,
    },
    {
      name: 'Success Rate',
      value: '89%',
      change: '+5% this month',
      changeType: 'positive',
      icon: TrendingUp,
    },
  ];

  const quickActions = [
    {
      name: 'Schedule Meeting',
      description: 'Find the best time across time zones',
      icon: Calendar,
      color: 'bg-blue-500 hover:bg-blue-600',
      page: 'scheduling',
    },
    {
      name: 'Generate Agenda',
      description: 'AI-powered meeting preparation',
      icon: FileText,
      color: 'bg-emerald-500 hover:bg-emerald-600',
      page: 'agenda',
    },
    {
      name: 'View Reminders',
      description: 'Check follow-ups and tasks',
      icon: Bell,
      color: 'bg-amber-500 hover:bg-amber-600',
      page: 'reminders',
    },
    {
      name: 'Past Meetings',
      description: 'Review meeting history',
      icon: Users,
      color: 'bg-indigo-500 hover:bg-indigo-600',
      page: 'past-meetings',
    },
  ];

  const upcomingMeetings = [
    {
      title: 'Quarterly Review - APAC Region',
      time: '10:00 AM IST',
      partner: 'Singapore Office',
      status: 'confirmed',
    },
    {
      title: 'Product Launch Discussion',
      time: '2:30 PM IST',
      partner: 'UK Distribution',
      status: 'pending',
    },
    {
      title: 'Strategic Planning',
      time: '4:00 PM IST',
      partner: 'US West Coast',
      status: 'confirmed',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Welcome to AI Meeting Buddy</h1>
        <p className="mt-2 text-gray-600">Streamline your vendor-distributor meetings with AI-powered scheduling and agenda generation.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.name}
              className="relative overflow-hidden rounded-lg bg-white px-4 pt-5 pb-4 shadow hover:shadow-md transition-shadow duration-200 sm:px-6 sm:pt-6"
            >
              <div>
                <div className="absolute rounded-md bg-blue-500 p-3">
                  <Icon className="h-6 w-6 text-white" aria-hidden="true" />
                </div>
                <p className="ml-16 truncate text-sm font-medium text-gray-500">{item.name}</p>
                <p className="ml-16 text-2xl font-semibold text-gray-900">{item.value}</p>
              </div>
              <div className="ml-16 flex items-baseline">
                <p className="text-sm text-green-600">{item.change}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.name}
                onClick={() => setCurrentPage(action.page)}
                className={`${action.color} text-white rounded-lg p-6 text-left transition-all duration-200 transform hover:scale-105`}
              >
                <Icon className="h-8 w-8 mb-3" />
                <h3 className="text-lg font-semibold mb-2">{action.name}</h3>
                <p className="text-sm opacity-90">{action.description}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Today's Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Today's Schedule</h3>
          </div>
          <div className="p-6 space-y-4">
            {upcomingMeetings.map((meeting, index) => (
              <div key={index} className="flex items-center space-x-4 p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
                <div className="flex-shrink-0">
                  <div className={`w-3 h-3 rounded-full ${meeting.status === 'confirmed' ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-gray-900">{meeting.title}</h4>
                  <p className="text-sm text-gray-500">{meeting.partner} • {meeting.time}</p>
                </div>
                <Clock className="h-4 w-4 text-gray-400" />
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Time Zone Overview</h3>
          </div>
          <div className="p-6 space-y-4">
            {[
              { region: 'India (IST)', time: new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' }) },
              { region: 'Singapore (SGT)', time: new Date().toLocaleTimeString('en-SG', { timeZone: 'Asia/Singapore' }) },
              { region: 'London (GMT)', time: new Date().toLocaleTimeString('en-GB', { timeZone: 'Europe/London' }) },
              { region: 'New York (EST)', time: new Date().toLocaleTimeString('en-US', { timeZone: 'America/New_York' }) },
            ].map((tz, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                <span className="text-sm font-medium text-gray-900">{tz.region}</span>
                <span className="text-sm text-gray-600 font-mono">{tz.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;