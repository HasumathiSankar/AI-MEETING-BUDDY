import React, { useState } from 'react';
import { Bell, CheckCircle, Clock, AlertTriangle, User, Calendar, Filter } from 'lucide-react';

const RemindersFollowups: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'overdue' | 'today' | 'upcoming'>('all');
  const [completedItems, setCompletedItems] = useState<Set<string>>(new Set());

  const mockReminders = [
    {
      id: '1',
      type: 'follow-up',
      title: 'Send Q3 Performance Report to APAC Team',
      description: 'Quarterly performance summary including KPIs and growth metrics',
      dueDate: new Date(Date.now() - 86400000), // Yesterday
      priority: 'high',
      assignedTo: 'Sarah Johnson',
      meetingRef: 'APAC Quarterly Review - Dec 15',
      status: 'overdue',
    },
    {
      id: '2',
      type: 'reminder',
      title: 'Prepare presentation for UK partnership meeting',
      description: 'Include market analysis and expansion strategy slides',
      dueDate: new Date(), // Today
      priority: 'high',
      assignedTo: 'You',
      meetingRef: 'UK Partnership Strategy - Dec 17',
      status: 'due-today',
    },
    {
      id: '3',
      type: 'follow-up',
      title: 'Review and approve new distributor contracts',
      description: 'Legal review of terms for Germany and France regions',
      dueDate: new Date(Date.now() + 86400000), // Tomorrow
      priority: 'medium',
      assignedTo: 'Legal Team',
      meetingRef: 'European Expansion - Dec 14',
      status: 'upcoming',
    },
    {
      id: '4',
      type: 'reminder',
      title: 'Schedule follow-up call with Singapore office',
      description: 'Discuss implementation timeline and resource allocation',
      dueDate: new Date(Date.now() + 172800000), // Day after tomorrow
      priority: 'medium',
      assignedTo: 'You',
      meetingRef: 'Singapore Product Launch - Dec 12',
      status: 'upcoming',
    },
    {
      id: '5',
      type: 'follow-up',
      title: 'Update CRM with new contact information',
      description: 'Add new stakeholder details from Australian partnership meeting',
      dueDate: new Date(Date.now() + 259200000), // 3 days
      priority: 'low',
      assignedTo: 'Marketing Team',
      meetingRef: 'Australia Partnership - Dec 11',
      status: 'upcoming',
    },
    {
      id: '6',
      type: 'reminder',
      title: 'Prepare agenda for next board meeting',
      description: 'Include partnership updates and financial projections',
      dueDate: new Date(Date.now() + 604800000), // 1 week
      priority: 'medium',
      assignedTo: 'You',
      meetingRef: 'Board Meeting Preparation',
      status: 'upcoming',
    },
  ];

  const getFilteredReminders = () => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today.getTime() + 86400000);

    switch (activeTab) {
      case 'overdue':
        return mockReminders.filter(r => r.dueDate < today);
      case 'today':
        return mockReminders.filter(r => 
          r.dueDate >= today && r.dueDate < tomorrow
        );
      case 'upcoming':
        return mockReminders.filter(r => r.dueDate >= tomorrow);
      default:
        return mockReminders;
    }
  };

  const toggleComplete = (id: string) => {
    const newCompleted = new Set(completedItems);
    if (newCompleted.has(id)) {
      newCompleted.delete(id);
    } else {
      newCompleted.add(id);
    }
    setCompletedItems(newCompleted);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'overdue': return 'border-red-500 bg-red-50';
      case 'due-today': return 'border-yellow-500 bg-yellow-50';
      case 'upcoming': return 'border-green-500 bg-green-50';
      default: return 'border-gray-300 bg-white';
    }
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today.getTime() + 86400000);
    const yesterday = new Date(today.getTime() - 86400000);

    if (date >= today && date < tomorrow) {
      return 'Today';
    } else if (date >= tomorrow && date < new Date(tomorrow.getTime() + 86400000)) {
      return 'Tomorrow';
    } else if (date >= yesterday && date < today) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  const filteredReminders = getFilteredReminders();
  const stats = {
    total: mockReminders.length,
    overdue: mockReminders.filter(r => r.dueDate < new Date()).length,
    today: mockReminders.filter(r => {
      const today = new Date();
      const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      const endOfDay = new Date(startOfDay.getTime() + 86400000);
      return r.dueDate >= startOfDay && r.dueDate < endOfDay;
    }).length,
    completed: completedItems.size,
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Reminders & Follow-ups</h1>
        <p className="mt-2 text-gray-600">Stay on top of your meeting commitments and action items.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <div className="bg-white rounded-lg shadow p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Bell className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Total Tasks</dt>
                <dd className="text-lg font-medium text-gray-900">{stats.total}</dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-6 w-6 text-red-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Overdue</dt>
                <dd className="text-lg font-medium text-gray-900">{stats.overdue}</dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Clock className="h-6 w-6 text-yellow-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Due Today</dt>
                <dd className="text-lg font-medium text-gray-900">{stats.today}</dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Completed</dt>
                <dd className="text-lg font-medium text-gray-900">{stats.completed}</dd>
              </dl>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            {[
              { key: 'all', label: 'All Tasks', count: stats.total },
              { key: 'overdue', label: 'Overdue', count: stats.overdue },
              { key: 'today', label: 'Due Today', count: stats.today },
              { key: 'upcoming', label: 'Upcoming', count: stats.total - stats.overdue - stats.today },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as any)}
                className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.key
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
                <span className="ml-2 bg-gray-100 text-gray-600 py-0.5 px-2.5 rounded-full text-xs">
                  {tab.count}
                </span>
              </button>
            ))}
          </nav>
        </div>

        {/* Tasks List */}
        <div className="divide-y divide-gray-200">
          {filteredReminders.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="mx-auto h-12 w-12 text-gray-300" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No tasks found</h3>
              <p className="mt-1 text-sm text-gray-500">
                {activeTab === 'all' ? 'All tasks are up to date!' : `No ${activeTab} tasks at the moment.`}
              </p>
            </div>
          ) : (
            filteredReminders.map((reminder) => (
              <div
                key={reminder.id}
                className={`p-6 border-l-4 ${getStatusColor(reminder.status)} ${
                  completedItems.has(reminder.id) ? 'opacity-60' : ''
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <button
                      onClick={() => toggleComplete(reminder.id)}
                      className={`mt-1 flex-shrink-0 w-5 h-5 border-2 rounded transition-colors ${
                        completedItems.has(reminder.id)
                          ? 'bg-green-500 border-green-500 text-white'
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      {completedItems.has(reminder.id) && (
                        <CheckCircle className="w-full h-full" />
                      )}
                    </button>
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className={`text-sm font-medium ${
                          completedItems.has(reminder.id) ? 'line-through text-gray-500' : 'text-gray-900'
                        }`}>
                          {reminder.title}
                        </h3>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(reminder.priority)}`}>
                          {reminder.priority}
                        </span>
                      </div>
                      
                      <p className="text-sm text-gray-600 mb-2">{reminder.description}</p>
                      
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span className="flex items-center">
                          <User className="h-3 w-3 mr-1" />
                          {reminder.assignedTo}
                        </span>
                        <span className="flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          {reminder.meetingRef}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm font-medium ${
                      reminder.status === 'overdue' ? 'text-red-600' :
                      reminder.status === 'due-today' ? 'text-yellow-600' :
                      'text-gray-600'
                    }`}>
                      {formatDate(reminder.dueDate)}
                    </span>
                    <div className={`w-2 h-2 rounded-full ${
                      reminder.type === 'reminder' ? 'bg-blue-500' : 'bg-green-500'
                    }`} title={reminder.type}></div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
            Add New Reminder
          </button>
          <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors">
            Create Follow-up Task
          </button>
          <button className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition-colors">
            Export Tasks Report
          </button>
        </div>
      </div>
    </div>
  );
};

export default RemindersFollowups;