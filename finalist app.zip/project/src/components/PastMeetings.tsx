import React, { useState } from 'react';
import { Calendar, Users, FileText, Search, Filter, Clock, MapPin, TrendingUp } from 'lucide-react';

const PastMeetings: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRegion, setFilterRegion] = useState('all');
  const [selectedMeeting, setSelectedMeeting] = useState<any>(null);

  const mockPastMeetings = [
    {
      id: '1',
      title: 'APAC Quarterly Business Review',
      date: new Date('2024-12-15'),
      region: 'Singapore',
      participants: ['Sarah Johnson', 'Michael Chen', 'Priya Sharma', 'David Kim'],
      duration: '2 hours',
      type: 'Quarterly Review',
      outcomes: [
        'Exceeded Q3 revenue targets by 15%',
        'Identified 3 new market opportunities',
        'Agreed on Q4 expansion strategy for Vietnam'
      ],
      keyTopics: [
        'Q3 Performance Analysis',
        'Market Expansion Strategy',
        'Resource Allocation for Q4',
        'Partnership Opportunities'
      ],
      followUps: [
        'Prepare Vietnam market entry proposal - Due Dec 22',
        'Schedule stakeholder alignment call - Due Dec 18',
        'Review budget allocation for new initiatives - Due Dec 20'
      ],
      satisfaction: 4.5,
      notes: 'Highly productive session with clear action items. Team alignment on expansion strategy was excellent.'
    },
    {
      id: '2',
      title: 'UK Distribution Partnership Strategy',
      date: new Date('2024-12-12'),
      region: 'United Kingdom',
      participants: ['Emma Thompson', 'James Wilson', 'Lisa Anderson'],
      duration: '1.5 hours',
      type: 'Strategic Planning',
      outcomes: [
        'Finalized partnership agreement terms',
        'Established timeline for product rollout',
        'Defined KPIs and success metrics'
      ],
      keyTopics: [
        'Partnership Agreement Review',
        'Distribution Channel Optimization',
        'Marketing Collaboration Plans',
        'Performance Metrics Definition'
      ],
      followUps: [
        'Legal review of partnership documents - Due Dec 19',
        'Create joint marketing campaign proposal - Due Dec 25',
        'Set up monthly performance review schedule - Due Dec 16'
      ],
      satisfaction: 4.2,
      notes: 'Good progress on partnership terms. Need to accelerate legal review process.'
    },
    {
      id: '3',
      title: 'Germany Market Entry Discussion',
      date: new Date('2024-12-10'),
      region: 'Germany',
      participants: ['Hans Mueller', 'Anna Schmidt', 'Thomas Weber', 'Priya Sharma'],
      duration: '2 hours',
      type: 'Market Entry',
      outcomes: [
        'Approved market entry strategy for Germany',
        'Identified key distribution partners',
        'Set preliminary timeline for launch'
      ],
      keyTopics: [
        'Market Research Analysis',
        'Competitive Landscape Review',
        'Local Partnership Opportunities',
        'Regulatory Compliance Requirements'
      ],
      followUps: [
        'Conduct detailed competitor analysis - Due Dec 24',
        'Initiate contact with potential partners - Due Dec 21',
        'Research regulatory requirements - Due Dec 18'
      ],
      satisfaction: 4.0,
      notes: 'Comprehensive discussion about German market. Need more detailed competitive analysis.'
    },
    {
      id: '4',
      title: 'Australia Partnership Review',
      date: new Date('2024-12-08'),
      region: 'Australia',
      participants: ['Robert Smith', 'Jennifer Brown', 'Mark Taylor'],
      duration: '1 hour',
      type: 'Performance Review',
      outcomes: [
        'Reviewed Q3 partnership performance',
        'Addressed operational challenges',
        'Planned improvements for Q4'
      ],
      keyTopics: [
        'Partnership Performance Metrics',
        'Operational Challenges',
        'Process Improvements',
        'Q4 Goals Setting'
      ],
      followUps: [
        'Implement new reporting system - Due Dec 22',
        'Schedule training session for partners - Due Dec 26',
        'Review and update SLA terms - Due Dec 30'
      ],
      satisfaction: 3.8,
      notes: 'Identified several operational issues. Good action plan to address challenges.'
    },
    {
      id: '5',
      title: 'Japan Technology Integration Meeting',
      date: new Date('2024-12-05'),
      region: 'Japan',
      participants: ['Hiroshi Tanaka', 'Yuki Nakamura', 'Kenji Yamamoto', 'Sarah Johnson'],
      duration: '1.5 hours',
      type: 'Technical Discussion',
      outcomes: [
        'Finalized API integration specifications',
        'Resolved technical compatibility issues',
        'Established testing timeline'
      ],
      keyTopics: [
        'API Integration Requirements',
        'Technical Architecture Review',
        'Testing Protocols',
        'Security Compliance'
      ],
      followUps: [
        'Complete API documentation - Due Dec 20',
        'Set up testing environment - Due Dec 17',
        'Conduct security audit - Due Dec 23'
      ],
      satisfaction: 4.3,
      notes: 'Excellent technical collaboration. Clear resolution of integration challenges.'
    },
    {
      id: '6',
      title: 'US West Coast Product Launch',
      date: new Date('2024-12-03'),
      region: 'USA West',
      participants: ['Rachel Martinez', 'Brian Johnson', 'Alex Chen', 'Maria Garcia'],
      duration: '2.5 hours',
      type: 'Product Launch',
      outcomes: [
        'Approved product launch timeline',
        'Defined marketing strategy',
        'Allocated launch budget'
      ],
      keyTopics: [
        'Product Launch Strategy',
        'Marketing Campaign Planning',
        'Budget Allocation',
        'Success Metrics Definition'
      ],
      followUps: [
        'Finalize marketing materials - Due Dec 28',
        'Coordinate with PR agency - Due Dec 15',
        'Set up analytics tracking - Due Dec 19'
      ],
      satisfaction: 4.6,
      notes: 'Very successful launch planning session. Team is well-aligned and motivated.'
    }
  ];

  const getFilteredMeetings = () => {
    return mockPastMeetings.filter(meeting => {
      const matchesSearch = meeting.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           meeting.region.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           meeting.type.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesRegion = filterRegion === 'all' || meeting.region.toLowerCase().includes(filterRegion.toLowerCase());
      return matchesSearch && matchesRegion;
    });
  };

  const regions = ['All', 'Singapore', 'United Kingdom', 'Germany', 'Australia', 'Japan', 'USA'];

  const filteredMeetings = getFilteredMeetings();

  const stats = {
    totalMeetings: mockPastMeetings.length,
    averageSatisfaction: (mockPastMeetings.reduce((sum, m) => sum + m.satisfaction, 0) / mockPastMeetings.length).toFixed(1),
    totalHours: mockPastMeetings.reduce((sum, m) => sum + parseFloat(m.duration.split(' ')[0]), 0),
    regionsActive: new Set(mockPastMeetings.map(m => m.region)).size,
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Past Meetings</h1>
        <p className="mt-2 text-gray-600">Review your meeting history, outcomes, and insights for better future planning.</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <div className="bg-white rounded-lg shadow p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Calendar className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Total Meetings</dt>
                <dd className="text-lg font-medium text-gray-900">{stats.totalMeetings}</dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Avg. Satisfaction</dt>
                <dd className="text-lg font-medium text-gray-900">{stats.averageSatisfaction}/5</dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Clock className="h-6 w-6 text-purple-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Total Hours</dt>
                <dd className="text-lg font-medium text-gray-900">{stats.totalHours}h</dd>
              </dl>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <MapPin className="h-6 w-6 text-orange-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-gray-500 truncate">Active Regions</dt>
                <dd className="text-lg font-medium text-gray-900">{stats.regionsActive}</dd>
              </dl>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search meetings, regions, or topics..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          <div className="sm:w-48">
            <select
              value={filterRegion}
              onChange={(e) => setFilterRegion(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {regions.map((region) => (
                <option key={region} value={region.toLowerCase()}>
                  {region}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Meetings List */}
      <div className="grid grid-cols-1 gap-6">
        {filteredMeetings.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <Calendar className="mx-auto h-12 w-12 text-gray-300" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No meetings found</h3>
            <p className="mt-1 text-sm text-gray-500">Try adjusting your search terms or filters.</p>
          </div>
        ) : (
          filteredMeetings.map((meeting) => (
            <div key={meeting.id} className="bg-white rounded-lg shadow hover:shadow-md transition-shadow">
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">{meeting.title}</h3>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {meeting.type}
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-6 text-sm text-gray-600 mb-4">
                      <span className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {meeting.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </span>
                      <span className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {meeting.region}
                      </span>
                      <span className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {meeting.duration}
                      </span>
                      <span className="flex items-center">
                        <Users className="h-4 w-4 mr-1" />
                        {meeting.participants.length} participants
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-sm font-medium text-gray-900 mb-2">Key Outcomes</h4>
                        <ul className="text-sm text-gray-600 space-y-1">
                          {meeting.outcomes.slice(0, 2).map((outcome, index) => (
                            <li key={index} className="flex items-start">
                              <span className="w-1.5 h-1.5 bg-green-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                              {outcome}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium text-gray-900 mb-2">Main Topics</h4>
                        <div className="flex flex-wrap gap-1">
                          {meeting.keyTopics.slice(0, 3).map((topic, index) => (
                            <span key={index} className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-gray-100 text-gray-700">
                              {topic}
                            </span>
                          ))}
                          {meeting.keyTopics.length > 3 && (
                            <span className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-gray-100 text-gray-700">
                              +{meeting.keyTopics.length - 3} more
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end space-y-2 ml-6">
                    <div className="flex items-center space-x-1">
                      <span className="text-sm text-gray-600">Satisfaction:</span>
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <div
                            key={i}
                            className={`w-3 h-3 rounded-full ${
                              i < Math.floor(meeting.satisfaction) ? 'bg-yellow-400' : 'bg-gray-200'
                            }`}
                          />
                        ))}
                        <span className="ml-1 text-sm font-medium text-gray-700">{meeting.satisfaction}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedMeeting(selectedMeeting?.id === meeting.id ? null : meeting)}
                      className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                    >
                      {selectedMeeting?.id === meeting.id ? 'Hide Details' : 'View Details'}
                    </button>
                  </div>
                </div>

                {/* Expanded Details */}
                {selectedMeeting?.id === meeting.id && (
                  <div className="mt-6 pt-6 border-t border-gray-200 space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-900 mb-2">All Participants</h4>
                      <div className="flex flex-wrap gap-2">
                        {meeting.participants.map((participant, index) => (
                          <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs bg-blue-100 text-blue-800">
                            <Users className="h-3 w-3 mr-1" />
                            {participant}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-900 mb-2">Complete Outcomes</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {meeting.outcomes.map((outcome, index) => (
                          <li key={index} className="flex items-start">
                            <span className="w-1.5 h-1.5 bg-green-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                            {outcome}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-900 mb-2">Follow-up Actions</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {meeting.followUps.map((followUp, index) => (
                          <li key={index} className="flex items-start">
                            <FileText className="h-4 w-4 mt-0.5 mr-2 text-yellow-500 flex-shrink-0" />
                            {followUp}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-900 mb-2">Notes</h4>
                      <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md">{meeting.notes}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default PastMeetings;